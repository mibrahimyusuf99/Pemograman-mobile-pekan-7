class Mahasiswa {
  final int id;
  final String nim;
  final String nama;
  final String jenisKelamin;
  final String kelas;
  final String jurusan;
  final int tahunMasuk;
  final String agama;
  final String alamatAsal;
  final String? alamatSekarang;
  final String? foto;
  final String? linkIg;
  final String? linkLinkedin;

  Mahasiswa({
    required this.id,
    required this.nim,
    required this.nama,
    required this.jenisKelamin,
    required this.kelas,
    required this.jurusan,
    required this.tahunMasuk,
    required this.agama,
    required this.alamatAsal,
    this.alamatSekarang,
    this.foto,
    this.linkIg,
    this.linkLinkedin,
  });

  factory Mahasiswa.fromJson(Map<String, dynamic> j) {
    return Mahasiswa(
      id: j['id'],
      nim: j['nim'],
      nama: j['nama'],
      jenisKelamin: j['jenis_kelamin'],
      kelas: j['kelas'],
      jurusan: j['jurusan'],
      tahunMasuk: int.tryParse(j['tahun_masuk'].toString()) ?? 0,
      agama: j['agama'],
      alamatAsal: j['alamat_asal'],
      alamatSekarang: j['alamat_sekarang'],
      foto: j['foto'] != null
    ? 'http://127.0.0.1:8000/storage/${j['foto']}'
    : null,
      linkIg: j['link_ig'],
      linkLinkedin: j['link_linkedin'],
    );
  }
}
