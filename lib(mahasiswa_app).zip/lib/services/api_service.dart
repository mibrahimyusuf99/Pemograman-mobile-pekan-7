import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/mahasiswa.dart';

class ApiService {
  static const baseUrl = 'http://127.0.0.1:8000/api';
  static String token = '';

  static Map<String, String> get headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };

  // Login
  static Future<bool> login(String username, String password) async {
    final res = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: jsonEncode({
        'username': username,
        'password': password,
      }),
    );
    if (res.statusCode == 200) {
      final json = jsonDecode(res.body);
      token = json['token'];
      return true;
    }
    return false;
  }

  // GET semua mahasiswa
  static Future<List<Mahasiswa>> getAll() async {
    final res = await http.get(
      Uri.parse('$baseUrl/mahasiswa'),
      headers: headers,
    );
    if (res.statusCode == 200) {
      final json = jsonDecode(res.body);
      return (json['data'] as List)
          .map((e) => Mahasiswa.fromJson(e))
          .toList();
    }
    throw Exception('Gagal load data');
  }

  // POST tambah mahasiswa
  static Future<bool> store(Map<String, dynamic> body) async {
    final res = await http.post(
      Uri.parse('$baseUrl/mahasiswa'),
      headers: headers,
      body: jsonEncode(body),
    );
    return res.statusCode == 201;
  }

  // PUT update mahasiswa
  static Future<bool> update(int id, Map<String, dynamic> body) async {
    final res = await http.put(
      Uri.parse('$baseUrl/mahasiswa/$id'),
      headers: headers,
      body: jsonEncode(body),
    );
    return res.statusCode == 200;
  }

  // DELETE mahasiswa
  static Future<bool> delete(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/mahasiswa/$id'),
      headers: headers,
    );
    return res.statusCode == 200;
  }

  // Upload foto mahasiswa
  static Future<bool> uploadFoto(int id, String filePath) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/mahasiswa/$id/foto'),
    );
    request.headers['Authorization'] = 'Bearer $token';
    request.headers['Accept'] = 'application/json';
    request.files.add(await http.MultipartFile.fromPath('foto', filePath));
    final response = await request.send();
    final res = await http.Response.fromStream(response);
    print('Upload foto status: ${res.statusCode}');
    print('Upload foto body: ${res.body}');
    return res.statusCode == 200;
  }
}