import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import '../models/mahasiswa.dart';
import '../services/api_service.dart';

class FormMahasiswaScreen extends StatefulWidget {
  final Mahasiswa? mahasiswa;

  const FormMahasiswaScreen({super.key, this.mahasiswa});

  @override
  State<FormMahasiswaScreen> createState() => _FormMahasiswaScreenState();
}

class _FormMahasiswaScreenState extends State<FormMahasiswaScreen> {
  final _nimC = TextEditingController();
  final _namaC = TextEditingController();
  final _kelasC = TextEditingController();
  final _jurusanC = TextEditingController();
  final _tahunC = TextEditingController();
  final _agamaC = TextEditingController();
  final _alamatAsalC = TextEditingController();
  final _alamatSekarangC = TextEditingController();
  final _linkIgC = TextEditingController();
  final _linkLinkedinC = TextEditingController();
  String _jenisKelamin = 'L';
  File? _foto;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.mahasiswa != null) {
      final m = widget.mahasiswa!;
      _nimC.text = m.nim;
      _namaC.text = m.nama;
      _kelasC.text = m.kelas;
      _jurusanC.text = m.jurusan;
      _tahunC.text = m.tahunMasuk.toString();
      _agamaC.text = m.agama;
      _alamatAsalC.text = m.alamatAsal;
      _alamatSekarangC.text = m.alamatSekarang ?? '';
      _linkIgC.text = m.linkIg ?? '';
      _linkLinkedinC.text = m.linkLinkedin ?? '';
      _jenisKelamin = m.jenisKelamin;
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _foto = File(picked.path));
    }
  }

  Future<void> _submit() async {
    setState(() => _isLoading = true);

    final body = {
      'nim': _nimC.text,
      'nama': _namaC.text,
      'jenis_kelamin': _jenisKelamin,
      'kelas': _kelasC.text,
      'jurusan': _jurusanC.text,
      'tahun_masuk': int.tryParse(_tahunC.text) ?? 0,
      'agama': _agamaC.text,
      'alamat_asal': _alamatAsalC.text,
      'alamat_sekarang': _alamatSekarangC.text,
      'link_ig': _linkIgC.text,
      'link_linkedin': _linkLinkedinC.text,
    };

    bool success;
    int? savedId;

    if (widget.mahasiswa == null) {
      final res = await http.post(
        Uri.parse('${ApiService.baseUrl}/mahasiswa'),
        headers: ApiService.headers,
        body: jsonEncode(body),
      );
      if (res.statusCode == 201) {
        success = true;
        final json = jsonDecode(res.body);
        savedId = json['data']['id'];
      } else {
        success = false;
      }
    } else {
      success = await ApiService.update(widget.mahasiswa!.id, body);
      savedId = widget.mahasiswa!.id;
    }

    if (success && _foto != null && savedId != null) {
      await ApiService.uploadFoto(savedId, _foto!.path);
    }

    setState(() => _isLoading = false);

    if (success) {
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal menyimpan data!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.mahasiswa != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Mahasiswa' : 'Tambah Mahasiswa'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Foto — ini bagian yang diupdate
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.blue.shade100,
                backgroundImage: _foto != null
                    ? FileImage(_foto!)
                    : (widget.mahasiswa?.foto != null
                        ? NetworkImage(widget.mahasiswa!.foto!)
                        : null) as ImageProvider?,
                child: (_foto == null && widget.mahasiswa?.foto == null)
                    ? const Icon(Icons.camera_alt, size: 40, color: Colors.blue)
                    : null,
              ),
            ),
            const SizedBox(height: 8),
            const Text('Tap untuk pilih foto', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),

            _buildField('NIM', _nimC),
            _buildField('Nama', _namaC),
            _buildField('Kelas', _kelasC),
            _buildField('Jurusan', _jurusanC),
            _buildField('Tahun Masuk', _tahunC, keyboardType: TextInputType.number),
            _buildField('Agama', _agamaC),
            _buildField('Alamat Asal', _alamatAsalC),
            _buildField('Alamat Sekarang', _alamatSekarangC),
            _buildField('Link Instagram', _linkIgC),
            _buildField('Link LinkedIn', _linkLinkedinC),

            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Jenis Kelamin: '),
                Radio(
                  value: 'L',
                  groupValue: _jenisKelamin,
                  onChanged: (v) => setState(() => _jenisKelamin = v!),
                ),
                const Text('Laki-laki'),
                Radio(
                  value: 'P',
                  groupValue: _jenisKelamin,
                  onChanged: (v) => setState(() => _jenisKelamin = v!),
                ),
                const Text('Perempuan'),
              ],
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(isEdit ? 'Update' : 'Simpan',
                        style: const TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller,
      {TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}